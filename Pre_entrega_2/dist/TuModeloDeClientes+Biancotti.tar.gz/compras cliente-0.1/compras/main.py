from cliente import Cliente
from registro import Registro

cliente_1 = []

cliente_1 = Registro ()

print (cliente_1)

cliente_1.comprar ()

cliente_1.imprimir_compras()