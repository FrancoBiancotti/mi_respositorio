from setuptools import setup

setup(
    name="compras cliente",
    version="0.1",
    description="Modelo de entidades para compras",
    author="Franco",
    author_email="francobiancotti@gmail.com",
    packages=["compras"],)